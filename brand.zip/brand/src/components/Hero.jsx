function Hero()
{
    return(
        <main className="hero container">
            <div className="hero-content">
                <h1>Tales of Uzumaki Naruto</h1>
                <p> Naruto worked hard to gain the village's acknowledgement all the while chasing his dream to become Hokage. In the following years, through many hardships and ordeals, he became a capable ninja, regarded as a hero both by the villagers, and soon after, the rest of the world, becoming known as the <b> Hero of the Hidden Leaf</b></p>
                {/* <br /> */}
                <div className="hero-btn">

                    <button className="pri">Details</button>
                    <button className="sec">Chakra</button>

                </div>
                  {/* <br /> */}
                <div className="shop">
                    <p>Book Avaliable at </p>
                    <div className="shop-logo">
                        <img src="/images/ama.png" alt="" style={{width : "100px"}}/>
                        <img src="/images/flip.png" alt="" style={{width : "55px"}}/>
                    </div>
                </div>
            </div>
            <div className="hero-img">
            <img src="/images/Naruto.png" alt="" style={{width : "900px" , height:"800px"}} />

            </div>
        </main>
    )
}
export default Hero;