function Navigation()
{
   return(
    <div>

   <nav >
    <div className="logo">
       <img src="/images/logo.jpeg" alt="Logo" title="logo" style={{width : "100px"}}/>
    </div>

    <ul>
      <li href ="#">Menu</li>
      <li href ="#">Location</li>
      <li href ="#">About</li>
      <li href ="#">Contact</li>
    </ul>
    <button>Login</button>
   </nav>
     
  </div>
   )
}
export default Navigation