import './App.css'
import Navigation from './components/Navigation';
import Hero from './components/Hero';
function App()
{
  return (
  <div>
    <Navigation/>
    <br />
    <Hero/>
    </div>
  )
}
export default App;